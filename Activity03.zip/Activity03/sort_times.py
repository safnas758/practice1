import time       # Used to measure how long sorting takes
import random     # Used to generate random arrays for testing
import plotter    # Our custom graph drawing module
from sorts import insertion_sort, merge_sort, quick_insertion_sort  # Import sorting functions
import turtle     # Needed to close the graph window at the end

# List of array sizes we will use for testing
SIZES = [200, 500, 800, 1100, 1400, 1700, 2000]

def sort_function_timer(sort_function, an_array):
    """
    Measures how long it takes to sort a copy of 'an_array' using the given 'sort_function'.
    
    Args:
        sort_function: A sorting function like insertion_sort.
        an_array: A list of numbers to be sorted.

    Returns:
        The time (in seconds) it took to sort the array.
    """
    start = time.perf_counter()  # Start the timer
    sort_function(an_array.copy())  # Use a copy to avoid modifying the original
    return time.perf_counter() - start  # Return elapsed time

def plot_sort_time_using_random_arrays(sort_function):
    """
    Creates a new data series for random arrays and times how long the sort takes for each size.

    Args:
        sort_function: A sorting function to be tested.
    """
    print("timing", sort_function.__name__)  # Show which sort we're testing
    plotter.new_series()  # Start a new line/series in the plot

    # Loop through each size in SIZES
    for size in SIZES:
        # Create a random array of the given size
        an_array = [random.randint(0, size) for _ in range(size)]

        # Time the sorting function and add the result to the plot
        plotter.add_data_point(sort_function_timer(sort_function, an_array))

def plot_sort_time_using_sorted_z(sort_function):
    """
    Creates a new data series for already sorted arrays and times how long the sort takes.

    Args:
        sort_function: A sorting function to be tested.
    """
    print("timing", sort_function.__name__)  # Show which sort we're testing
    plotter.new_series()  # Start a new line/series in the plot

    # Loop through each size in SIZES
    for size in SIZES:
        # Create a sorted array (0 to size-1)
        an_array = list(range(size))

        # Time the sorting function and add the result to the plot
        plotter.add_data_point(sort_function_timer(sort_function, an_array))

def main():
    """
    Main function that runs the sort comparisons and shows the plots.
    """
    # --- Random Arrays Test ---
    plotter.init("Random Arrays", "Size", "Time in sec")  # Set up plot title and axis labels
    plot_sort_time_using_random_arrays(insertion_sort)
    plot_sort_time_using_random_arrays(merge_sort)
    plot_sort_time_using_random_arrays(quick_insertion_sort)
    plotter.plot()  # Draw the graph
    turtle.done()   # Keep turtle window open until closed manually

    # --- Sorted Arrays Test ---
    plotter.init("Sorted Arrays", "Size", "Time in sec")
    plot_sort_time_using_sorted_z(insertion_sort)
    plot_sort_time_using_sorted_z(merge_sort)
    plot_sort_time_using_sorted_z(quick_insertion_sort)
    plotter.plot()
    turtle.done()

# Only run this code if this file is executed directly (not imported)
if __name__ == "__main__":
    main()
