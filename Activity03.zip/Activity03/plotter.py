import turtle
import math

# constants
__X_LENGTH = 500
__Y_LENGTH = 500
__MARGIN = 40
__COLORS = ["red", "yellow", "blue", "green", "brown", "gold", "orange", 
    "maroon", "violet", "magenta", "purple", "navy", "skyblue", "cyan", 
    "turquoise", "lightgreen", "green", "darkgreen", "chocolate", "black",
    "gray"]

__TITLE = ""
__X_AXIS_LABEL = ""
__Y_AXIS_LABEL = ""
__DATA_POINTS = [[]]
__INCLUDE_DATA_LABELS = True
__MAX_Y = 0
__MIN_Y = float('inf')

def reset():
    global __TITLE, __X_AXIS_LABEL, __Y_AXIS_LABEL, __DATA_POINTS
    __TITLE = ""
    __X_AXIS_LABEL = ""
    __Y_AXIS_LABEL = ""
    __DATA_POINTS.clear()
    new_series()
    turtle.reset()

def title(title=None):
    global __TITLE
    if title is not None:
        __TITLE = title
    return __TITLE

def x_axis_label(label=None):
    global __X_AXIS_LABEL
    if label is not None:
        __X_AXIS_LABEL = label
    return __X_AXIS_LABEL

def y_axis_label(label=None):
    global __Y_AXIS_LABEL
    if label is not None:
        __Y_AXIS_LABEL = label
    return __Y_AXIS_LABEL

def init(plot_title, x_label, y_label, include_data_labels=True):
    reset()
    title(plot_title)
    x_axis_label(x_label)
    y_axis_label(y_label)
    global __INCLUDE_DATA_LABELS, __MAX_Y, __MIN_Y
    __INCLUDE_DATA_LABELS = include_data_labels
    __MAX_Y = 0
    __MIN_Y = float('inf')

def new_series():
    __DATA_POINTS.append([])

def add_data_point(y):
    global __MAX_Y, __MIN_Y
    __DATA_POINTS[-1].append(y)
    __MAX_Y = max(__MAX_Y, y)
    __MIN_Y = min(__MIN_Y, y)

def __draw_axis(length, ticks, label, right=True, is_y_axis=False, max_val=1):
    pensize = turtle.pensize()
    tick_distance = length / (ticks + 1)
    turtle.pencolor("black")

    # Centered label
    turtle.forward(length / 2)
    angle = 90 if right else -90
    turtle.right(angle)
    turtle.forward(20)
    turtle.write(label, align="center")
    turtle.back(20)
    turtle.right(-angle)
    turtle.back(length / 2)

    turtle.down()
    for i in range(ticks + 1):
        turtle.pensize(3)
        turtle.forward(tick_distance)
        turtle.pensize(1)
        turtle.left(90)
        turtle.forward(5)
        # Draw numeric labels
        turtle.write(str(round(max_val * (i+1)/(ticks+1), 2)), align="left" if is_y_axis else "center")
        turtle.back(10)
        turtle.forward(5)
        turtle.right(90)
    turtle.up()
    turtle.back(length)
    turtle.pensize(pensize)

def plot(trace_plot=True, log=False):
    turtle.reset()
    turtle.setworldcoordinates(-__MARGIN, -__MARGIN, __X_LENGTH + __MARGIN, __Y_LENGTH + __MARGIN)
    turtle.up()
    turtle.hideturtle()
    turtle.tracer(0)
    
    turtle.setpos(__X_LENGTH / 2, __Y_LENGTH + 20)
    turtle.write(__TITLE, align="center")
    turtle.home()

    # draw x and y axes
    number_of_points = len(__DATA_POINTS[0])
    __draw_axis(__X_LENGTH, number_of_points, __X_AXIS_LABEL, right=True)
    turtle.left(90)
    __draw_axis(__Y_LENGTH, 10, __Y_AXIS_LABEL, right=False, is_y_axis=True, max_val=__MAX_Y)
    
    for i, data_series in enumerate(__DATA_POINTS):
        plot_data_points(data_series, __COLORS[i % len(__COLORS)], trace_plot, log)
    
    turtle.tracer()

def plot_data_points(data_points, dot_color, trace_plot=True, log=False):
    turtle.tracer(trace_plot)
    number_of_points = len(data_points)
    x_distance = __X_LENGTH / (number_of_points + 1)
    x = x_distance

    prev_x = None
    prev_y = None

    for value in data_points:
        if log:
            scale = 1 / __MIN_Y + 0.05
            log_max = math.log(__MAX_Y * scale, 10)
            y = math.log(value * scale, 10) / log_max * __Y_LENGTH
        else:
            y = value / __MAX_Y * __Y_LENGTH

        # Move to current point and draw dot
        turtle.up()
        turtle.setpos(x, y)
        if __INCLUDE_DATA_LABELS:
            turtle.write(str(round(value, 4)))
        turtle.dot(6, dot_color)

        # Draw line from previous point to current point
        if prev_x is not None and prev_y is not None:
            turtle.up()
            turtle.setpos(prev_x, prev_y)
            turtle.down()
            turtle.pencolor(dot_color)
            turtle.pensize(2)
            turtle.goto(x, y)
            turtle.up()

        prev_x = x
        prev_y = y
        x += x_distance

    turtle.up()

def plot_point(x, data_point, dot_color, log=False):
    pensize = turtle.pensize()
    pencolor = turtle.pencolor()
    down = turtle.isdown()

    if log:
        scale = 1 / __MIN_Y + 0.05
        log_max = math.log(__MAX_Y * scale, 10)
        point = math.log(data_point * scale, 10)
        y = point / log_max * __Y_LENGTH
    else:
        y = data_point / __MAX_Y * __Y_LENGTH

    turtle.setpos(x, y)
    if __INCLUDE_DATA_LABELS:
        turtle.write(str(round(data_point, 4)))
    turtle.down()
    turtle.pensize(3)
    turtle.pencolor(dot_color)
    turtle.dot()

    turtle.pensize(pensize)
    turtle.pencolor(pencolor)
    if not down:
        turtle.up()
