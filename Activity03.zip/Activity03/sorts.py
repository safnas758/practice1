"""
Defines different sorting algorithms to be tested and timed.
"""

def insertion_sort(arr):
    """
    Sorts using Insertion Sort algorithm.
    """
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr

def merge_sort(arr):
    """
    Sorts using Merge Sort algorithm.
    """
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    """
    Merges two sorted lists.
    """
    result = []
    while left and right:
        if left[0] < right[0]:
            result.append(left.pop(0))
        else:
            result.append(right.pop(0))
    return result + left + right

def quick_sort(arr):
    """
    Sorts using Quick Sort algorithm.
    """
    if len(arr) <= 1:
        return arr
    pivot = arr[0]
    left = [x for x in arr[1:] if x < pivot]
    right = [x for x in arr[1:] if x >= pivot]
    return quick_sort(left) + [pivot] + quick_sort(right)

def quick_insertion_sort(arr, depth=0):
    """
    Hybrid sort combining quick sort and insertion sort.
    Switches to insertion sort for small arrays or deep recursion.
    """
    if len(arr) <= 10 or depth > 20:
        return insertion_sort(arr)
    pivot = arr[0]
    left = [x for x in arr[1:] if x < pivot]
    right = [x for x in arr[1:] if x >= pivot]
    return quick_insertion_sort(left, depth + 1) + [pivot] + quick_insertion_sort(right, depth + 1)
